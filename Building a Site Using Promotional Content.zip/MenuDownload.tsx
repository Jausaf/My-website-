import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

export default function MenuDownload() {
  const handleDownload = async () => {
    try {
      const response = await fetch('/menu.pdf');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Hotel_Buddha_Residency_Menu.pdf';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Failed to download menu:', error);
    }
  };

  return (
    <Button
      onClick={handleDownload}
      className="gap-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white"
    >
      <Download className="w-4 h-4" />
      Download Menu PDF
    </Button>
  );
}
