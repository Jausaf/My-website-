import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-foreground text-background py-12 md:py-16">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663770132509/a3vyFccyzEa2pbzzSu8Qwb/logo-buddha-residency-4jJR2mLSqR2HxNkNQwc5eL.png"
                alt="Hotel Buddha Residency"
                className="h-8 w-8"
              />
              Buddha Residency
            </h3>
            <p className="text-sm text-background/80">
              Where tradition meets comfort. Experience authentic Indian hospitality.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="/" className="hover:text-primary transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="/menu" className="hover:text-primary transition-colors">
                  Menu
                </a>
              </li>
              <li>
                <a href="/about" className="hover:text-primary transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="/visit" className="hover:text-primary transition-colors">
                  Visit Us
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex gap-2">
                <Phone className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <a
                  href="tel:+917979995378"
                  className="hover:text-primary transition-colors"
                >
                  +91-7979995378
                </a>
              </li>
              <li className="flex gap-2">
                <MapPin className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <span>NH-80 Kiul Station, Garhi Bishanpur, Lakhisarai, Bihar 811310</span>
              </li>
              <li className="flex gap-2">
                <Clock className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <span>9:00 AM – 8:00 PM</span>
              </li>
            </ul>
          </div>

          {/* Amenities */}
          <div>
            <h4 className="font-semibold mb-4">Amenities</h4>
            <ul className="space-y-2 text-sm">
              <li>✓ Luxury Rooms</li>
              <li>✓ Multicuisine Restaurant</li>
              <li>✓ Free WiFi</li>
              <li>✓ Parking</li>
              <li>✓ Laundry Service</li>
              <li>✓ Banquet Hall</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center text-sm text-background/70">
            <p>&copy; 2026 Hotel Buddha Residency. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-background transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="hover:text-background transition-colors">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
