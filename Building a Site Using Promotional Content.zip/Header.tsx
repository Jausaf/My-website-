import { useState } from 'react';
import { Link } from 'wouter';
import { Menu, X, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', href: '/' },
    { label: 'Menu', href: '/menu' },
    { label: 'About Us', href: '/about' },
    { label: 'Visit Us', href: '/visit' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border shadow-premium-sm">
      <div className="container flex items-center justify-between py-4">
        {/* Logo */}
        <Link href="/">
          <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663770132509/a3vyFccyzEa2pbzzSu8Qwb/logo-buddha-residency-gC8de9BPSQ4yBW8rpBrWDK.webp"
              alt="Hotel Buddha Residency"
              className="h-10 w-10"
            />
            <span className="hidden sm:inline font-bold text-lg text-foreground">
              Buddha Residency
            </span>
          </a>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href}>
              <a className="text-foreground hover:text-primary transition-colors font-medium text-sm">
                {link.label}
              </a>
            </Link>
          ))}
        </nav>

        {/* CTA Button & Mobile Menu */}
        <div className="flex items-center gap-4">
          <a
            href="tel:+917979995378"
            className="hidden sm:flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
          >
            <Phone className="h-4 w-4" />
            <span className="text-sm font-medium">+91-7979995378</span>
          </a>

          <Button
            asChild
            className="hidden sm:inline-flex bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <a href="#reserve">Reserve Now</a>
          </Button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 hover:bg-accent/10 rounded-lg transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background animate-in fade-in slide-in-from-top-2">
          <nav className="container py-4 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <a
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-foreground hover:text-primary transition-colors font-medium py-2"
                >
                  {link.label}
                </a>
              </Link>
            ))}
            <Button
              asChild
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <a href="#reserve" onClick={() => setMobileMenuOpen(false)}>
                Reserve Now
              </a>
            </Button>
            <a
              href="tel:+917979995378"
              className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors py-2"
            >
              <Phone className="h-4 w-4" />
              <span className="font-medium">+91-7979995378</span>
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
