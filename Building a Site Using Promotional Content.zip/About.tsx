import { CheckCircle } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function About() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Page Header */}
        <section className="py-12 md:py-16 bg-gradient-to-b from-primary/5 to-background border-b border-border">
          <div className="container">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">About Us</h1>
            <div className="w-16 h-1 bg-primary rounded-full" />
          </div>
        </section>

        {/* Story Section */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <div className="max-w-3xl">
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Hotel Buddha Residency stands as a beacon of hospitality in Lakhisarai, Bihar. Built on the principles of authentic service and genuine warmth, our hotel has become a trusted destination for travelers seeking comfort, quality, and cultural immersion.
              </p>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Located strategically at NH-80 near Kiul Station, we offer the perfect blend of accessibility and serenity. Whether you're visiting for business, leisure, or spiritual exploration, Hotel Buddha Residency provides a sanctuary of comfort where every guest is treated like family.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Our commitment to excellence is reflected in every aspect of our service—from our thoughtfully designed rooms to our authentic multicuisine restaurant, from our attentive staff to our premium amenities. We believe that hospitality is not just about providing a place to stay, but creating memories that last a lifetime.
              </p>
            </div>
          </div>
        </section>

        {/* Mission & Values */}
        <section className="py-16 md:py-24 bg-muted/30 border-y border-border">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="p-8 bg-background rounded-lg border border-border">
                <h3 className="text-2xl font-bold mb-4 text-primary">Our Mission</h3>
                <p className="text-muted-foreground">
                  To provide exceptional hospitality that exceeds expectations, blending traditional Indian warmth with modern comfort and convenience.
                </p>
              </div>
              <div className="p-8 bg-background rounded-lg border border-border">
                <h3 className="text-2xl font-bold mb-4 text-secondary">Our Vision</h3>
                <p className="text-muted-foreground">
                  To be the most trusted and beloved hospitality destination in Lakhisarai, known for authentic service and genuine care for our guests.
                </p>
              </div>
              <div className="p-8 bg-background rounded-lg border border-border">
                <h3 className="text-2xl font-bold mb-4 text-accent">Our Values</h3>
                <p className="text-muted-foreground">
                  Integrity, authenticity, excellence, and guest-centric service form the foundation of everything we do.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <h2 className="text-3xl font-bold mb-12 text-center">Why Choose Hotel Buddha Residency?</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                {
                  title: 'Prime Location',
                  description: 'Strategically located at NH-80 near Kiul Station, easily accessible and close to major attractions.',
                },
                {
                  title: 'Luxury Accommodations',
                  description: 'Spacious, well-appointed rooms with modern amenities and traditional warmth.',
                },
                {
                  title: 'Authentic Cuisine',
                  description: 'Multicuisine restaurant serving authentic Indian and international dishes prepared by expert chefs.',
                },
                {
                  title: 'Premium Services',
                  description: 'Free WiFi, laundry service, parking, 24/7 room service, and dedicated guest support.',
                },
                {
                  title: 'Excellent Rating',
                  description: '4.0-star rating with 270+ positive reviews from satisfied guests.',
                },
                {
                  title: 'Affordable Luxury',
                  description: 'Competitive pricing starting from ₹1,960 per night without compromising on quality.',
                },
              ].map((item, index) => (
                <div key={index} className="flex gap-4">
                  <CheckCircle className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                    <p className="text-muted-foreground">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Amenities Showcase */}
        <section className="py-16 md:py-24 bg-muted/30 border-y border-border">
          <div className="container">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Amenities</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                'Luxury Rooms with AC',
                'Multicuisine Restaurant',
                'Free High-Speed WiFi',
                'Ample Parking',
                'Laundry & Dry Cleaning',
                'Banquet & Conference Hall',
                '24/7 Room Service',
                'Complimentary Breakfast',
                'Travel Assistance',
              ].map((amenity, index) => (
                <div key={index} className="p-6 bg-background rounded-lg border border-border text-center">
                  <p className="font-semibold text-foreground">{amenity}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Guest Testimonials */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <h2 className="text-3xl font-bold mb-12 text-center">What Our Guests Say</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  quote:
                    'Wonderful stay! The rooms were clean and comfortable, and the staff was incredibly helpful. The food was delicious too!',
                  author: 'Rajesh Kumar',
                },
                {
                  quote:
                    'Best hotel in Lakhisarai. Great location, excellent service, and reasonable prices. Highly recommended!',
                  author: 'Priya Singh',
                },
                {
                  quote:
                    'The meals were delicious and freshly made. The hospitality was warm and genuine. Will definitely visit again!',
                  author: 'Amit Patel',
                },
              ].map((testimonial, index) => (
                <div key={index} className="p-8 bg-muted/50 rounded-lg border border-border">
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-primary text-lg">
                        ★
                      </span>
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 italic">"{testimonial.quote}"</p>
                  <p className="font-semibold text-foreground">— {testimonial.author}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 md:py-24 bg-gradient-to-r from-primary/10 to-secondary/10 border-t border-border">
          <div className="container text-center">
            <h2 className="text-3xl font-bold mb-4">Experience Hotel Buddha Residency</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join us for an unforgettable stay filled with comfort, warmth, and authentic hospitality.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/visit"
                className="inline-flex items-center justify-center px-8 py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg font-medium transition-colors"
              >
                Book Your Stay
              </a>
              <a
                href="tel:+917979995378"
                className="inline-flex items-center justify-center px-8 py-3 border border-primary text-primary hover:bg-primary/5 rounded-lg font-medium transition-colors"
              >
                Call Us
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
