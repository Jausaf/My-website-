import { Link } from 'wouter';
import { Star, MapPin, Users, Utensils } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative h-screen md:h-[600px] flex items-center overflow-hidden">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663770132509/a3vyFccyzEa2pbzzSu8Qwb/hero-lobby-NsSNJazrU3fjmSnJbc6rH4.webp"
            alt="Hotel Lobby"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30" />

          <div className="container relative z-10 flex flex-col justify-center h-full">
            <div className="max-w-2xl">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 fade-in-up">
                Where Tradition Meets Comfort
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8 fade-in-up">
                Experience authentic Indian hospitality in the heart of Lakhisarai. Luxury accommodations, exquisite dining, and warm service await you.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 fade-in-up">
                <Button
                  asChild
                  size="lg"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <a href="/visit">Reserve Your Stay</a>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                >
                  <a href="/menu">Explore Menu</a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Stats */}
        <section className="py-12 md:py-16 bg-background border-b border-border">
          <div className="container">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 mb-2">
                  <Star className="h-5 w-5 fill-primary text-primary" />
                  <span className="text-3xl font-bold text-primary">4.0</span>
                </div>
                <p className="text-sm text-muted-foreground">Rating</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-primary mb-2">270+</p>
                <p className="text-sm text-muted-foreground">Reviews</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-primary mb-2">₹1,960</p>
                <p className="text-sm text-muted-foreground">From/Night</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-primary mb-2">24/7</p>
                <p className="text-sm text-muted-foreground">Service</p>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Amenities */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Premium Amenities</h2>
              <div className="w-16 h-1 bg-primary mx-auto rounded-full" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Rooms */}
              <div className="group hover-lift p-8 bg-card rounded-lg border border-border">
                <div className="mb-4">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <MapPin className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">Luxury Rooms</h3>
                <p className="text-muted-foreground">
                  Spacious, well-appointed rooms with modern amenities and warm hospitality.
                </p>
              </div>

              {/* Dining */}
              <div className="group hover-lift p-8 bg-card rounded-lg border border-border">
                <div className="mb-4">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-secondary/10 rounded-lg group-hover:bg-secondary/20 transition-colors">
                    <Utensils className="h-6 w-6 text-secondary" />
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">Multicuisine Restaurant</h3>
                <p className="text-muted-foreground">
                  Authentic Indian and international cuisine prepared by expert chefs.
                </p>
              </div>

              {/* Services */}
              <div className="group hover-lift p-8 bg-card rounded-lg border border-border">
                <div className="mb-4">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-accent/10 rounded-lg group-hover:bg-accent/20 transition-colors">
                    <Users className="h-6 w-6 text-accent" />
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">Premium Services</h3>
                <p className="text-muted-foreground">
                  WiFi, laundry, parking, banquet facilities, and 24/7 room service.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Property Gallery */}
        <section className="py-16 md:py-24 bg-muted/30">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Beautiful Property</h2>
              <div className="w-16 h-1 bg-primary mx-auto rounded-full mb-4" />
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Experience the perfect blend of modern architecture and traditional hospitality. Our property features elegant spaces designed for your comfort.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663770132509/a3vyFccyzEa2pbzzSu8Qwb/hero-lobby-NsSNJazrU3fjmSnJbc6rH4.webp"
                alt="Hotel Exterior Night View"
                className="rounded-lg shadow-lg h-80 object-cover w-full"
              />
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663770132509/a3vyFccyzEa2pbzzSu8Qwb/hero-dining-dF7beeLFGhr82X5GAC9oh.webp"
                alt="Hotel Banquet and Events Space"
                className="rounded-lg shadow-lg h-80 object-cover w-full"
              />
            </div>
          </div>
        </section>

        {/* Dining Showcase */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Exquisite Dining</h2>
                <div className="w-16 h-1 bg-primary rounded-full mb-6" />
                <p className="text-muted-foreground mb-6">
                  Our multicuisine restaurant offers an exceptional culinary experience. From traditional Indian specialties to international favorites, every dish is prepared with premium ingredients and authentic techniques.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex gap-3">
                    <span className="text-primary font-bold">✓</span>
                    <span>Authentic Indian Cuisine</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-primary font-bold">✓</span>
                    <span>International Dishes</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-primary font-bold">✓</span>
                    <span>Daily Buffet Service</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-primary font-bold">✓</span>
                    <span>Room Service Available</span>
                  </li>
                </ul>
                <Button
                  asChild
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <Link href="/menu">View Full Menu</Link>
                </Button>
              </div>
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663770132509/a3vyFccyzEa2pbzzSu8Qwb/hero-dining-dF7beeLFGhr82X5GAC9oh.webp"
                alt="Restaurant"
                className="rounded-lg shadow-lg h-96 object-cover"
              />
            </div>
          </div>
        </section>

        {/* Room Showcase */}
        <section className="py-16 md:py-24 bg-muted/30">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663770132509/a3vyFccyzEa2pbzzSu8Qwb/hero-room-GRfuDwsqTLY6Ct5Sw6MUjx.webp"
                alt="Hotel Room"
                className="rounded-lg shadow-lg h-96 object-cover"
              />
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Comfortable Stays</h2>
                <div className="w-16 h-1 bg-primary rounded-full mb-6" />
                <p className="text-muted-foreground mb-6">
                  Our thoughtfully designed rooms blend contemporary comfort with traditional warmth. Each room is equipped with modern amenities to ensure a restful and memorable stay.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex gap-3">
                    <span className="text-primary font-bold">✓</span>
                    <span>Air-Conditioned Rooms</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-primary font-bold">✓</span>
                    <span>Premium Bedding</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-primary font-bold">✓</span>
                    <span>Modern Bathrooms</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-primary font-bold">✓</span>
                    <span>Free WiFi</span>
                  </li>
                </ul>
                <Button
                  asChild
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <a href="/visit">Book Now</a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 md:py-24 bg-gradient-to-r from-primary/10 to-secondary/10 border-y border-border">
          <div className="container text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Experience Serene Luxury?</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Book your stay today and discover the perfect blend of tradition and comfort in Lakhisarai.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <a href="/visit">Reserve Your Stay</a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
              >
                <a href="tel:+917979995378">Call Us Now</a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
