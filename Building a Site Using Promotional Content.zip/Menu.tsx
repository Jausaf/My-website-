import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Download } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import MenuDownload from '@/components/MenuDownload';
import { menuItems } from '@/data/menu';

export default function Menu() {
  const [selectedCategory, setSelectedCategory] = useState<'veg' | 'non-veg' | 'beverage'>('veg');

  const vegItems = menuItems.filter((item) => item.category === 'veg');
  const nonVegItems = menuItems.filter((item) => item.category === 'non-veg');
  const beverages = menuItems.filter((item) => item.category === 'beverage');

  const renderMenuItems = (items: typeof menuItems) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {items.map((item) => (
        <Card
          key={item.id}
          className="overflow-hidden hover-lift border border-border bg-card hover:shadow-lg transition-all group"
        >
          {/* Image Section */}
          {item.image && (
            <div className="relative h-48 overflow-hidden bg-muted">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
          )}

          {/* Content Section */}
          <div className="p-6">
            <div className="flex items-start justify-between gap-4 mb-2">
              <h3 className="text-lg font-bold text-foreground flex-1">{item.name}</h3>
              <span className="text-xl font-bold text-primary whitespace-nowrap">₹{item.price}</span>
            </div>

            {item.description && (
              <p className="text-sm text-muted-foreground mb-4">{item.description}</p>
            )}

            <div className="mt-4 flex items-center gap-2">
              <div className="h-0.5 flex-1 bg-primary/20 rounded-full" />
              <span className="text-xs font-medium text-primary">Available</span>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Page Header */}
        <section className="py-12 md:py-16 bg-gradient-to-b from-primary/5 to-background border-b border-border">
          <div className="container">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 mb-6">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Menu</h1>
                <div className="w-16 h-1 bg-primary rounded-full mb-4" />
                <p className="text-lg text-muted-foreground max-w-2xl">
                  Discover our carefully curated selection of authentic Indian and international cuisine, prepared with premium ingredients and traditional techniques.
                </p>
              </div>
              <div className="flex-shrink-0">
                <MenuDownload />
              </div>
            </div>
          </div>
        </section>

        {/* Menu Categories */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <Tabs
              defaultValue="veg"
              value={selectedCategory}
              onValueChange={(value) => setSelectedCategory(value as 'veg' | 'non-veg' | 'beverage')}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-3 mb-12 bg-muted/50 p-1 rounded-lg">
                <TabsTrigger
                  value="veg"
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <span className="hidden sm:inline">Vegetarian</span>
                  <span className="sm:hidden">Veg</span>
                </TabsTrigger>
                <TabsTrigger
                  value="non-veg"
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <span className="hidden sm:inline">Non-Vegetarian</span>
                  <span className="sm:hidden">Non-Veg</span>
                </TabsTrigger>
                <TabsTrigger
                  value="beverage"
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  Beverages
                </TabsTrigger>
              </TabsList>

              <TabsContent value="veg" className="animate-in fade-in">
                <div className="mb-8">
                  <h2 className="text-2xl font-bold mb-2">Vegetarian Delights</h2>
                  <p className="text-muted-foreground">
                    Explore our selection of delicious vegetarian dishes crafted with fresh ingredients.
                  </p>
                </div>
                {renderMenuItems(vegItems)}
              </TabsContent>

              <TabsContent value="non-veg" className="animate-in fade-in">
                <div className="mb-8">
                  <h2 className="text-2xl font-bold mb-2">Non-Vegetarian Specialties</h2>
                  <p className="text-muted-foreground">
                    Savor our premium non-vegetarian dishes prepared with authentic recipes.
                  </p>
                </div>
                {renderMenuItems(nonVegItems)}
              </TabsContent>

              <TabsContent value="beverage" className="animate-in fade-in">
                <div className="mb-8">
                  <h2 className="text-2xl font-bold mb-2">Refreshing Beverages</h2>
                  <p className="text-muted-foreground">
                    Quench your thirst with our selection of traditional and modern beverages.
                  </p>
                </div>
                {renderMenuItems(beverages)}
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Dining Info */}
        <section className="py-16 md:py-24 bg-muted/30 border-t border-border">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center p-8 bg-card rounded-lg border border-border">
                <h3 className="text-xl font-bold mb-2">Operating Hours</h3>
                <p className="text-muted-foreground">
                  9:00 AM – 8:00 PM
                  <br />
                  <span className="text-sm">Room service 24/7</span>
                </p>
              </div>
              <div className="text-center p-8 bg-card rounded-lg border border-border">
                <h3 className="text-xl font-bold mb-2">Dining Options</h3>
                <p className="text-muted-foreground">
                  Dine-in • Room Service
                  <br />
                  <span className="text-sm">Buffet & À la carte</span>
                </p>
              </div>
              <div className="text-center p-8 bg-card rounded-lg border border-border">
                <h3 className="text-xl font-bold mb-2">Reservations</h3>
                <p className="text-muted-foreground">
                  +91-7979995378
                  <br />
                  <span className="text-sm">Available for groups</span>
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Dine With Us?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Call us to make a reservation or visit us for an unforgettable culinary experience.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="tel:+917979995378"
                className="inline-flex items-center justify-center px-8 py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg font-medium transition-colors"
              >
                Call: +91-7979995378
              </a>
              <a
                href="/visit"
                className="inline-flex items-center justify-center px-8 py-3 border border-primary text-primary hover:bg-primary/5 rounded-lg font-medium transition-colors"
              >
                Visit Us
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
