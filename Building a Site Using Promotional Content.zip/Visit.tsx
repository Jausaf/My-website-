import { MapPin, Phone, Mail, Clock, Navigation } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function Visit() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Page Header */}
        <section className="py-12 md:py-16 bg-gradient-to-b from-primary/5 to-background border-b border-border">
          <div className="container">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Visit Us</h1>
            <div className="w-16 h-1 bg-primary rounded-full" />
          </div>
        </section>

        {/* Contact Information */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {/* Contact Details */}
              <div>
                <h2 className="text-3xl font-bold mb-8">Get in Touch</h2>

                <div className="space-y-6">
                  {/* Address */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10">
                        <MapPin className="h-6 w-6 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Address</h3>
                      <p className="text-muted-foreground">
                        NH-80 Kiul Station
                        <br />
                        Garhi Bishanpur
                        <br />
                        Lakhisarai, Bihar 811310
                        <br />
                        India
                      </p>
                    </div>
                  </div>

                  {/* Phone */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-secondary/10">
                        <Phone className="h-6 w-6 text-secondary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Phone</h3>
                      <a
                        href="tel:+917979995378"
                        className="text-primary hover:text-primary/80 transition-colors"
                      >
                        +91-7979995378
                      </a>
                    </div>
                  </div>

                  {/* Hours */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-accent/10">
                        <Clock className="h-6 w-6 text-accent" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Operating Hours</h3>
                      <p className="text-muted-foreground">
                        Restaurant: 9:00 AM – 8:00 PM
                        <br />
                        Room Service: 24/7
                        <br />
                        Reception: 24/7
                      </p>
                    </div>
                  </div>

                  {/* Directions */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10">
                        <Navigation className="h-6 w-6 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Directions</h3>
                      <p className="text-muted-foreground mb-3">
                        Located near Kiul Junction Railway Station on NH-80, easily accessible by road.
                      </p>
                      <a
                        href="https://maps.google.com/?q=Hotel+Buddha+Residency+Lakhisarai"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg transition-colors font-medium"
                      >
                        <Navigation className="h-4 w-4" />
                        Get Directions
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Form */}
              <div>
                <h2 className="text-3xl font-bold mb-8">Send us a Message</h2>

                <form className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Name</label>
                    <input
                      type="text"
                      placeholder="Your name"
                      className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email</label>
                    <input
                      type="email"
                      placeholder="your@email.com"
                      className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Phone</label>
                    <input
                      type="tel"
                      placeholder="+91-XXXXXXXXXX"
                      className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Message</label>
                    <textarea
                      placeholder="Tell us how we can help..."
                      rows={5}
                      className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full px-6 py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg font-medium transition-colors"
                  >
                    Send Message
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* Map Section */}
        <section className="py-16 md:py-24 bg-muted/30 border-y border-border">
          <div className="container">
            <h2 className="text-3xl font-bold mb-8 text-center">Find Us on the Map</h2>
            <div className="rounded-lg overflow-hidden shadow-premium h-96 md:h-[500px]">
              <iframe
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3614.8888888888887!2d86.3!3d25.4!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f4e3d3d3d3d3d3%3A0x3d3d3d3d3d3d3d3d!2sHotel%20Buddha%20Residency!5e0!3m2!1sen!2sin!4v1234567890"
              />
            </div>
          </div>
        </section>

        {/* Nearby Attractions */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <h2 className="text-3xl font-bold mb-12 text-center">Nearby Attractions</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  title: 'Kiul Junction Railway Station',
                  description: 'Just 3.7 km away, easily accessible by auto or taxi.',
                },
                {
                  title: 'Local Markets',
                  description: 'Explore traditional markets and local shopping areas nearby.',
                },
                {
                  title: 'Religious Sites',
                  description: 'Several temples and spiritual centers in close proximity.',
                },
                {
                  title: 'Scenic Routes',
                  description: 'Beautiful countryside and scenic drives around Lakhisarai.',
                },
                {
                  title: 'Local Cuisine',
                  description: 'Experience authentic Bihar cuisine at nearby eateries.',
                },
                {
                  title: 'Business District',
                  description: 'Convenient location for business travelers and meetings.',
                },
              ].map((attraction, index) => (
                <div key={index} className="p-6 bg-muted/50 rounded-lg border border-border">
                  <h3 className="font-bold text-lg mb-2">{attraction.title}</h3>
                  <p className="text-muted-foreground">{attraction.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Quick Booking CTA */}
        <section className="py-16 md:py-24 bg-gradient-to-r from-primary/10 to-secondary/10 border-t border-border">
          <div className="container text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Visit?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Book your stay today or call us for more information about our rooms and services.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="inline-flex items-center justify-center px-8 py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg font-medium transition-colors">
                Reserve Now
              </button>
              <a
                href="tel:+917979995378"
                className="inline-flex items-center justify-center px-8 py-3 border border-primary text-primary hover:bg-primary/5 rounded-lg font-medium transition-colors"
              >
                Call: +91-7979995378
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
